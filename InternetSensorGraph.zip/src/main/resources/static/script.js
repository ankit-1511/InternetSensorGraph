
const ctx = document.getElementById('sensorChart').getContext('2d');
let chart;

function fetchData(period) {
    fetch(`/api/sensor/data?period=${period}`)
        .then(response => response.json())
        .then(data => updateChart(data))
        .catch(error => console.error('Error fetching data:', error));
}

function updateChart(data) {
    const labels = data.map(item => item.time);
    const values = data.map(item => item.value);

    if (chart) {
        chart.destroy();
    }

    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Sensor Data',
                data: values,
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 2,
                fill: false
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Time'
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Value'
                    }
                }
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    fetchData('3hours');
});
