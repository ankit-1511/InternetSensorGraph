
package com.example.sensor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SensorDataService {

    @Autowired
    private SensorDataRepository sensorDataRepository;

    public List<SensorData> getDataForPeriod(String period) {
        LocalDateTime end = LocalDateTime.now();
        LocalDateTime start = calculateStartTime(period);

        return sensorDataRepository.findByTimeBetween(start, end);
    }

    private LocalDateTime calculateStartTime(String period) {
        LocalDateTime start = LocalDateTime.now();
        
        switch (period) {
            case "3hours":
                start = start.minusHours(3);
                break;
            case "24hours":
                start = start.minusDays(1);
                break;
            case "7days":
                start = start.minusWeeks(1);
                break;
            case "30days":
                start = start.minusMonths(1);
                break;
            case "1year":
                start = start.minusYears(1);
                break;
            default:
                throw new IllegalArgumentException("Invalid period: " + period);
        }
        
        return start;
    }
}
